# DealLens AI

Two accounts. One live briefing. Every number backed by evidence.

Built from the DealLens AI hackathon pitch deck: pick two CRM accounts, fetch their company, deal, activity and task records through **MCP**, and get five answers per account (health, revenue, engagement, risks, next steps). Every metric opens an evidence drawer showing its formula, timestamps and source records.

## Run

```bash
npm start          # http://localhost:3000  (Node 20+, zero dependencies)
npm test           # metrics, evidence, MCP client, grounding checks
```

## Architecture (matches slide 7)

```
CRM source  →  MCP layer            →  Intelligence             →  Web app
mcp/           server/mcpClient.js     server/metrics.js           public/
(demo CRM,     read-only; refuses      deterministic metrics +     two account columns,
 stdio MCP)    non-readOnly tools      evidence ledger             evidence drawer, exports
                                       server/narrative.js
                                       AI explains verified data only
```

- **Trust rules (slide 6):** every metric lists its formula, source record IDs, synced and computed timestamps. Missing fields are surfaced (⚠), never filled in. Metrics are deterministic code; the narrative is labelled as inference.
- **Grounded AI:** set `ANTHROPIC_API_KEY` to have Claude write the narrative. It only receives the computed brief, and the response is discarded if it contains a number not in that context (falls back to a template summary).
- **Read-only:** the client refuses any MCP tool without `readOnlyHint`.

## Connect a real CRM

The bundled `mcp/crm-server.js` is a demo CRM. To use a real one, point at another stdio MCP server that exposes the same five tools (`crm_list_companies`, `crm_get_company`, `crm_list_deals`, `crm_list_activities`, `crm_list_tasks`), or adapt `server/crm.js` to the HubSpot/Zoho tool names:

```bash
DEALLENS_MCP_COMMAND=npx DEALLENS_MCP_ARGS="-y your-crm-mcp-server" npm start
```

The HubSpot and Zoho remote MCP servers use HTTP + OAuth; add an HTTP transport to `mcpClient.js` for those (kept server-side so secrets never reach the browser).

## Rules (tunable in `server/metrics.js` → `RULES`)

| Rule | Default |
|---|---|
| Stale deal | no activity > 21 days |
| Engagement gap | no touchpoint > 30 days |
| Health | ≥75 Healthy, ≥50 Watch, else At risk |
| Revenue at risk | open deals that are stale or past close date |

## Scope

MVP only, as in slide 8: read-only, two accounts, source-linked metrics, refresh + last-sync, markdown brief, evidence manifest, print/PDF, account comparison. No write-back, ML, billing or mobile.
